/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { Component } from "react";
import {
  Button,
  StyleSheet,
  Text,
  View,
} from "react-native";
import {Picker} from '@react-native-picker/picker';




/*ECE HAVANCI 20190601022*/
export default class App extends Component {
  render() {
    return (
      <View style={{ alignItems: "center", justifyContent: "center", flex: 1 }}>
        <Classroom />
      </View>
    );
  }
}

class Lamp extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { color } = this.props;

    const isLit = (isLit) => {
      if (isLit === true) {
        return "ON";
      } else if (isLit === false) {
        return "OFF";
      }
    };

    const Color = () => {
      if (this.props.color === "red")
        return styles.red;
      else if (this.props.color === "green")
        return styles.green;
      else if (color === "blue")
        return this.props.color.blue;
    };
    return (
      <View style={(isLit(this.props.isLit) === "OFF" ? styles.green : Color())}>
        <Text>{isLit(this.props.isLit)}</Text>
      </View>
    );
  }
}

class LightSwitch extends Component {
  constructor(props) {
    super(props);
  }

  render() {

    return (
      <View style={styles.red}>
        <Button title={this.props.title ? "Turn light OFF " : "Turn light ON "}
                onPress={() => this.props.onButtonPress(this.props.isLightOn)

                } />
      </View>
    );
  }
}

class Classroom extends Component {
  state = {
    isLightOn: false,
    lightColor: "green",
  };

  render() {
    return (
      <View style={styles.blue}>
        <Lamp isLit={this.state.isLightOn} color={this.state.lightColor} />

        <LightSwitch onButtonPress={() =>
          this.setState(oldstate => {
            if (oldstate.isLightOn === true) {
              return {
                isLightOn: oldstate.isLightOn = false,
              };
            }
            if (oldstate.isLightOn === false) {
              return {
                isLightOn: oldstate.isLightOn = true,
              };
            }
          })} title={this.state.isLightOn}
        />

        <LightColorSelector color = {this.state.lightColor} colorChanger={(color)=>this.setState({lightColor:color})} />
      </View>
    );
  }
}

class LightColorSelector extends Component {
  render() {
    return (

      <View>
        <Picker selectedValue={this.props.color}
                onValueChange={(itemValue) => {
                  this.props.colorChanger(itemValue)

                }
                }
        >
          <Picker.Item label="Blue" value={"blue"} />
          <Picker.Item label="Green" value={"green"} />
          <Picker.Item label="Red" value={"red"} />
        </Picker>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  green: {
    backgroundColor: "green",
    padding: 5,
  },
  red: {
    backgroundColor: "red",
    padding: 5,
  },
  blue: {
    backgroundColor: "blue",
    padding: 5,
  },
});
